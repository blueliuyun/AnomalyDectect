the repository contains the whole project,
for specific Particle Filter implementation, please see

"code/particle_filter.py" and
"code/lab10.py"
