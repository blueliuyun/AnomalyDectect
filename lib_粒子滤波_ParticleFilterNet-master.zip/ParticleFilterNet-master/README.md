# ParticleFilterNet
实现基于RNN的粒子滤波网络，应用于纯惯导的地图匹配，解决室内定位问题
